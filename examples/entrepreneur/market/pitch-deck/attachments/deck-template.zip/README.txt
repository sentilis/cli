Placeholder pitch deck template for the Sentilis CLI examples.
